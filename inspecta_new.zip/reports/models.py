from django.db import models

# Create your models here.

class Report(models.Model):
	pass
